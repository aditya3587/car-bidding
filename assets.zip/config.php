<?php
	
	
	if(1==2){
	    $servername = "localhost";
    	$username = "root";
    	$password = "root";
    	$dbname = "nexa";
	    
	}else{
	    //server
	    $servername = "localhost";
    	$username = "sourcpxn_carbidd";
    	$password = "car@1q2w3e";
    	$dbname = "sourcpxn_car_bidding";
	    
	}

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);

	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	//echo "Connected successfully";
?>