<!-- ===================================================================== -->
<?php
  include 'modules/header.php';
?>



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title float-left">Ads Master</h4>

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                          <div class="col-lg-12">
                              <div class="card">
                                  <div class="card-body">
                                      <h4 class="m-t-0 header-title mb-4">View Ads</h4>

                                      <div class="table-responsive">
                                          <table id="datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                              <thead>
                                                  <tr>
                                                      <th width="30">#</th>
                                                      <th>Car Model</th>
                                                      <th>Car Company</th>
                                                      <th>Owner Name</th>
                                                      <th>Owner Contact</th>
                                                      <th>Evaluator Name</th>
                                                      <th>Base Price</th>
                                                      <th width="150">Actions</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                                  <tr>
                                                      <th scope="row">1</th>
                                                      <td>Swift</td>
                                                      <td>Maruti Suzuki</td>
                                                      <td>Mike Bhand</td>
                                                      <td>98989 89898</td>
                                                      <td>John Doe</td>
                                                      <td><b class="text-red">Not Set</b></td>
                                                      <td>
                                                        <a href="set-base-price.php" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>
                                                  <tr>
                                                      <th scope="row">2</th>
                                                      <td>Go+</td>
                                                      <td>Datsun</td>
                                                      <td>Pete Sariya</td>
                                                      <td>88989 88898</td>
                                                      <td>Smith Doe</td>
                                                      <td><b>&#8377; 5,20,000</b></td>
                                                      <td>
                                                        <a href="set-base-price.php" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>

                                              </tbody>
                                          </table>
                                      </div>

                                  </div>
                              </div>
                          </div>


                        </div> <!-- End row -->








                    </div> <!-- container -->

                </div> <!-- content -->



<!-- ============================================================ -->
<?php
  include 'modules/footer.php';
?>
