<!-- ===================================================================== -->
<?php
  include 'modules/header.php';
?>



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title float-left">Bid Master</h4>

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                          <div class="col-lg-12">
                              <div class="card">
                                  <div class="card-body">
                                      <h4 class="m-t-0 header-title mb-4">View Biddings</h4>

                                      <div class="table-responsive">
                                          <table id="datatable" class="table dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                              <thead>
                                                  <tr>
                                                      <th width="30">#</th>
                                                      <th>Car Model</th>
                                                      <th>Car Company</th>
                                                      <th>Base Price</th>
                                                      <th>Bid Start Date</th>
                                                      <th>Bid End Date</th>
                                                      <th>Status</th>
                                                      <th width="150">Actions</th>
                                                  </tr>
                                              </thead>
                                              <tbody>
                                                  <tr>
                                                      <th scope="row">1</th>
                                                      <td>Swift</td>
                                                      <td>Maruti Suzuki</td>
                                                      <td><b>&#8377; 5,20,000</b></td>
                                                      <td>-</td>
                                                      <td>-</td>
                                                      <td><span class="label label-warning">Pending</span></td>
                                                      <td>
                                                        <a href="set-bid.php" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>

                                                  <tr>
                                                      <th scope="row">2</th>
                                                      <td>Go+</td>
                                                      <td>Datsun</td>
                                                      <td><b>&#8377; 3,10,000</b></td>
                                                      <td>15 April, 2019</td>
                                                      <td>01 May, 2019</td>
                                                      <td><span class="label label-default">Not Started</span></td>
                                                      <td>
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>

                                                  <tr>
                                                      <th scope="row">3</th>
                                                      <td>Innova</td>
                                                      <td>Toyota</td>
                                                      <td><b>&#8377; 9,10,000</b></td>
                                                      <td>02 April, 2019</td>
                                                      <td>20 April, 2019</td>
                                                      <td><span class="label label-primary">In Progress</span></td>
                                                      <td>
                                                        <a href="bid-in-progress.php" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>

                                                  <tr>
                                                      <th scope="row">4</th>
                                                      <td>Innova</td>
                                                      <td>Toyota</td>
                                                      <td><b>&#8377; 7,10,000</b></td>
                                                      <td>10 March, 2019</td>
                                                      <td>20 March, 2019</td>
                                                      <td><span class="label label-green">Car Sold</span></td>
                                                      <td>
                                                        <a href="bid-completed.php" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>

                                                  <tr>
                                                      <th scope="row">5</th>
                                                      <td>Baleno</td>
                                                      <td>Maruti Suzuki Nexa</td>
                                                      <td><b>&#8377; 5,35,000</b></td>
                                                      <td>10 March, 2019</td>
                                                      <td>20 March, 2019</td>
                                                      <td><span class="label label-danger">Aborted</span></td>
                                                      <td>
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-primary">
                                                          <i class="far fa-eye"></i>
                                                        </a>
                                                        &nbsp;
                                                        <a href="#" class="btn btn-icon btn-sm waves-effect waves-light btn-danger">
                                                          <i class="far fa-trash-alt"></i>
                                                        </a>
                                                      </td>
                                                  </tr>


                                              </tbody>
                                          </table>
                                      </div>

                                  </div>
                              </div>
                          </div>


                        </div> <!-- End row -->








                    </div> <!-- container -->

                </div> <!-- content -->



<!-- ============================================================ -->
<?php
  include 'modules/footer.php';
?>
