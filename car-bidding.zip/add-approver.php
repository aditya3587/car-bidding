<!-- ===================================================================== -->
<?php
  include 'modules/header.php';
?>



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title float-left">Approvers Master</h4>

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                          <div class="col-lg-12">
                              <div class="card">
                                  <div class="card-body">
                                      <h4 class="m-t-0 header-title mb-4">Add Approver</h4>

                                      <form autocomplete="off">
                                            <div class="form-group">
                                                <label for="name">Name<span class="text-danger">*</span></label>
                                                <input type="text" name="name" parsley-trigger="change" required
                                                        placeholder="Enter name" class="form-control" id="name">
                                            </div>

                                            <div class="form-row">
                                                <div class="form-group col-md-6">
                                                    <label for="email">Email id<span class="text-danger">*</span></label>
                                                    <input type="email" name="email" parsley-trigger="change" required
                                                            placeholder="Enter email id" class="form-control" id="email">
                                                </div>
                                                <div class="form-group col-md-6">
                                                  <label for="tel">Contact no<span class="text-danger">*</span></label>
                                                  <input type="text" name="tel" parsley-trigger="change" required
                                                          placeholder="Enter contact no" class="form-control" id="tel">
                                                </div>
                                            </div>
                                            <div class="form-group text-right m-b-0">
                                              <input type="submit" class="btn btn-primary" value="Add Approver">
                                            </div>

                                        </form>

                                  </div>
                              </div>
                          </div>


                        </div> <!-- End row -->








                    </div> <!-- container -->

                </div> <!-- content -->



<!-- ============================================================ -->
<?php
  include 'modules/footer.php';
?>
