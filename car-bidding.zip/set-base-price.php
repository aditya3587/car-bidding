<!-- ===================================================================== -->
<?php
  include 'modules/header.php';
?>



            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title float-left">Ads Master</h4>

                                    <a href="#" data-toggle="modal" data-target=".set-base-price" class="btn btn-icon btn-md waves-effect waves-light btn-primary float-right">
                                      Set Base Price
                                    </a>

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->

                        <div class="row">
                          <div class="col-lg-12">
                              <div class="card">
                                  <div class="card-body">
                                      <h3 class="m-t-0 mb-4 text-dark-gray"><b>Maruti Swift VXi BSIV</b></h3>

                                      <h4 class="m-t-0 header-title mb-4">Overview</h4>

                                      <div class="row">
                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="far fa-calendar-alt"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Year
                                                    <span class="counter">2016</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="fas fa-road"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    KMs Driven
                                                    <span class="counter">35,000</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="fas fa-gas-pump"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Fuel Type
                                                    <span class="counter">Petrol</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="icofont-steering"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Transmission
                                                    <span class="counter">Manual</span>
                                                </div>
                                            </div>
                                        </div>
                                      </div><!-- end row -->

                                      <h4 class="m-t-0 header-title mb-4">Top Specifications</h4>

                                      <div class="row mb-5">
                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="fas fa-tachometer-alt"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Milege
                                                    <span class="counter">16.1 kmpl</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="fas fa-car"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Engine
                                                    <span class="counter">1197 cc</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="fas fa-bolt"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Max Power
                                                    <span class="counter">85 bhp</span>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-xl-3 col-sm-6">
                                            <div class="mini-stat border clearfix">
                                                <span class="mini-stat-icon dark">
                                                  <i class="icofont-power-zone"></i>
                                                </span>
                                                <div class="mini-stat-info">
                                                    Torque
                                                    <span class="counter">113Nm@ 4,500rpm</span>
                                                </div>
                                            </div>
                                        </div>
                                      </div><!-- end row -->


                                      <div class="col-md-12">
                                        <ul class="nav nav-tabs tabs-bordered">
                                            <li class="nav-item">
                                                <a href="#spec-b1" data-toggle="tab" aria-expanded="true" class="nav-link active">
                                                    <span class="d-block d-sm-none"><i class="fas fa-home"></i></span>
                                                    <span class="d-none d-sm-block">Specifications</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#eng-b1" data-toggle="tab" aria-expanded="false" class="nav-link">
                                                    <span class="d-block d-sm-none"><i class="fas fa-user"></i></span>
                                                    <span class="d-none d-sm-block">Engine</span>
                                                </a>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#feat-b1" data-toggle="tab" aria-expanded="false" class="nav-link">
                                                    <span class="d-block d-sm-none"><i class="far fa-envelope"></i></span>
                                                    <span class="d-none d-sm-block">Features</span>
                                                </a>
                                            </li>
                                        </ul>

                                        <div class="tab-content">
                                            <div class="tab-pane show active" id="spec-b1">
                                              <div class="table-responsive">
                                                  <table class="table table-borderless mb-0">
                                                      <tbody>
                                                        <tr>
                                                            <td width="300"><b>Color</b></td>
                                                            <td>White</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Gear Box</b></td>
                                                            <td>5 Speed</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Seating Capacity</b></td>
                                                            <td>5</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Synchronizers</b></td>
                                                            <td>All Gears</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Steering Type</b></td>
                                                            <td>Power</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Turning Radius</b></td>
                                                            <td>4.7 meters</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Front Break Type</b></td>
                                                            <td>Ventilated Disc</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Rear Break Type</b></td>
                                                            <td>Drum</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Top Speed</b></td>
                                                            <td>160 Kmph</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Acceleration</b></td>
                                                            <td>12.29 seconds</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Tyre Types</b></td>
                                                            <td>Tubeless, Radial</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Alloy Wheel Size</b></td>
                                                            <td>14 inchl</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>No of doors</b></td>
                                                            <td>5</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Cargo Volume</b></td>
                                                            <td>232 litre</td>
                                                        </tr>
                                                      </tbody>
                                                  </table>
                                              </div>
                                            </div>

                                            <div class="tab-pane" id="eng-b1">
                                              <div class="table-responsive">
                                                  <table class="table table-borderless mb-0">
                                                      <tbody>
                                                        <tr>
                                                            <td width="300"><b>Engine Type</b></td>
                                                            <td>In-Line Engine</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Displacement</b></td>
                                                            <td>1197</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Max Power</b></td>
                                                            <td>85ps @ 6,000rpm</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Max Torque</b></td>
                                                            <td>113Nm @ 4,500rpm</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>No Of Cylinder</b></td>
                                                            <td>4</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Valves Per Cylinder</b></td>
                                                            <td>4</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Valve Configuration</b></td>
                                                            <td>DOHC</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Fuel Supply System</b></td>
                                                            <td>MPFI</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>BoreX Stroke</b></td>
                                                            <td>74.0 x 75.5 mm</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Compression Ratio</b></td>
                                                            <td>9:01</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>Turbo Charger</b></td>
                                                            <td>Yes</td>
                                                        </tr>
                                                        <tr>
                                                            <td width="300"><b>superCharger</b></td>
                                                            <td>No</td>
                                                        </tr>
                                                      </tbody>
                                                  </table>
                                              </div>
                                            </div>

                                            <div class="tab-pane" id="feat-b1">
                                              <div id="accordion" class="m-b-20">
                                                  <div class="card mb-2">
                                                      <div class="card-header p-3" id="headingOne">
                                                          <h6 class="m-0">
                                                              <a href="#collapseOne" class="text-dark" data-toggle="collapse"
                                                                      aria-expanded="true"
                                                                      aria-controls="collapseOne">
                                                                  Car Interior Features
                                                              </a>
                                                          </h6>
                                                      </div>

                                                      <div id="collapseOne" class="collapse show"
                                                              aria-labelledby="headingOne" data-parent="#accordion">
                                                          <div class="card-body">
                                                              <ul>
                                                                <li>Air conditioner</li>
                                                                <li>Heater</li>
                                                                <li>Adjustable steering</li>
                                                                <li>Digital clock</li>
                                                                <li>Rear wash wiper</li>
                                                              </ul>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  <div class="card mb-2">
                                                      <div class="card-header p-3" id="headingTwo">
                                                          <h6 class="m-0">
                                                              <a href="#collapseTwo" class="text-dark collapsed" data-toggle="collapse"
                                                                      aria-expanded="false"
                                                                      aria-controls="collapseTwo">
                                                                  Car Comfort Features
                                                              </a>
                                                          </h6>
                                                      </div>
                                                      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                                              data-parent="#accordion">
                                                          <div class="card-body">
                                                              <ul>
                                                                <li>Power steering</li>
                                                                <li>Power windows front</li>
                                                                <li>Power windows rear</li>
                                                                <li>Remote trunk opener</li>
                                                                <li>Remote fuel lid opener</li>
                                                                <li>Low fuel warning light</li>
                                                                <li>Vanity mirror</li>
                                                                <li>Rear seat headrest</li>
                                                                <li>Height adjustable front seat belts</li>
                                                                <li>Cup holders front</li>
                                                                <li>Cup holders rear</li>
                                                              </ul>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  <div class="card mb-2">
                                                      <div class="card-header p-3" id="headingThree">
                                                          <h6 class="m-0">
                                                              <a href="#collapseThree" class="text-dark collapsed" data-toggle="collapse"
                                                                      aria-expanded="false"
                                                                      aria-controls="collapseThree">
                                                                  Car Safety Features
                                                              </a>
                                                          </h6>
                                                      </div>
                                                      <div id="collapseThree" class="collapse"
                                                              aria-labelledby="headingThree" data-parent="#accordion">
                                                          <div class="card-body">
                                                              <ul>
                                                                <li>Anti lock braking system</li>
                                                                <li>Central locking</li>
                                                                <li>Power door locks</li>
                                                                <li>Child safety lock</li>
                                                                <li>Anti theft alarm</li>
                                                                <li>Driver airbags</li>
                                                                <li>Passenger airbag</li>
                                                                <li>Rear seat belts</li>
                                                                <li>Seat belt warning</li>
                                                                <li>Adjustable seats</li>
                                                                <li>Keyless entry</li>
                                                              </ul>
                                                          </div>
                                                      </div>
                                                  </div>

                                                  <div class="card mb-2">
                                                      <div class="card-header p-3" id="headingFour">
                                                          <h6 class="m-0">
                                                              <a href="#collapseFour" class="text-dark collapsed" data-toggle="collapse"
                                                                      aria-expanded="false"
                                                                      aria-controls="collapseFour">
                                                                  Car Exterior Features
                                                              </a>
                                                          </h6>
                                                      </div>
                                                      <div id="collapseFour" class="collapse"
                                                              aria-labelledby="headingFour" data-parent="#accordion">
                                                          <div class="card-body">
                                                              <ul>
                                                                <li>Adjustable head lights</li>
                                                                <li>Manually adjustable exterior rear view mirror</li>
                                                                <li>Rear window wiper</li>
                                                                <li>Alloy wheels</li>
                                                                <li>Tinted glass</li>
                                                                <li>Front fog lights</li>
                                                                <li>Rear window wiper</li>
                                                                <li>Rear window defogger</li>
                                                                <li>Rear window defogger</li>
                                                              </ul>
                                                          </div>
                                                      </div>
                                                  </div>

                                              </div>
                                            </div>

                                        </div>
                                      </div>

                                      <hr class="mb-5" />

                                      <div class="col-md-12">
                                        <h4 class="m-t-0 header-title mb-4">Photos</h4>

                                        <div class="row">
                                          <div class="col-md-3 col-sm-6">
                                            <div class="cover">
                                              <img src="assets/images/car1.jpg" alt="">
                                            </div>
                                          </div>
                                          <div class="col-md-3 col-sm-6">
                                            <div class="cover">
                                              <img src="assets/images/car2.jpg" alt="">
                                            </div>
                                          </div>
                                          <div class="col-md-3 col-sm-6">
                                            <div class="cover">
                                              <img src="assets/images/car3.jpg" alt="">
                                            </div>
                                          </div>
                                          <div class="col-md-3 col-sm-6">
                                            <div class="cover">
                                              <img src="assets/images/car4.jpg" alt="">
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                  </div>
                              </div>
                          </div>


                        </div> <!-- End row -->








                    </div> <!-- container -->

                </div> <!-- content -->



<!-- ============================================================ -->
<?php
  include 'modules/footer.php';
?>



<div class="modal fade set-base-price" tabindex="-1" role="dialog" aria-labelledby="setBasePrice" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title" id="setBasePrice">Set Base Price</h4>
              <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          </div>
          <div class="modal-body">
              <h4 class="text-center mb-2">Enter the amount as a base price for <br /> <b>Maruti Swift VXi BSIV</b></h4>
              <form autofill="off">
                <div class="form-group">
                  <input type="text" class="form-control" name="" value="&#8377; ">
                </div>
                <div class="form-group text-right">
                  <input type="submit" class="btn btn-secondary" data-dismiss="modal" name="" value="Close">
                  &nbsp;
                  <input type="submit" class="btn btn-primary" name="" value="Set Base Price">
                </div>
              </form>
          </div>
      </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
